package com.ddff.ddffmod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

/**
 * Builds a 9 (wide) x 6 (deep) wooden box in front of the player.
 * "Zero depth": nothing is dug below the ground except replacing the single floor layer.
 *
 * Coordinates: u = left->right (0..8), v = near->far (0..5), h = height (0 = player's feet level).
 */
public final class HouseBuilder {
    private static final int WIDTH = 9;
    private static final int DEPTH = 6;
    private static final int FLAG_NORMAL = 3;   // update neighbours + clients
    private static final int FLAG_QUIET = 18;   // clients only, skip shape updates (beds / doors)

    private final ServerLevel level;
    private final BlockPos base;
    private final Direction fwd;
    private final Direction right;

    private HouseBuilder(ServerLevel level, BlockPos base, Direction fwd) {
        this.level = level;
        this.base = base;
        this.fwd = fwd;
        this.right = fwd.getClockWise();
    }

    public static void build(ServerLevel level, BlockPos playerPos, Direction facing) {
        new HouseBuilder(level, playerPos, facing).buildHouse();
    }

    private BlockPos at(int u, int v, int h) {
        // front wall starts 2 blocks ahead of the player, door is centred on the player's line
        return base.relative(fwd, 2 + v).relative(right, u - 4).above(h);
    }

    private void put(BlockPos pos, BlockState state) {
        level.setBlock(pos, state, FLAG_NORMAL);
    }

    private void put(BlockPos pos, BlockState state, int flags) {
        level.setBlock(pos, state, flags);
    }

    private void buildHouse() {
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState planks = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState log = Blocks.OAK_LOG.defaultBlockState();

        // 1) clear the space
        for (int u = 0; u < WIDTH; u++) {
            for (int v = 0; v < DEPTH; v++) {
                for (int h = 0; h <= 3; h++) {
                    put(at(u, v, h), air);
                }
            }
        }

        // 2) floor, roof, walls
        for (int u = 0; u < WIDTH; u++) {
            for (int v = 0; v < DEPTH; v++) {
                put(at(u, v, -1), planks);
                put(at(u, v, 3), planks);
                boolean sideWall = (u == 0 || u == WIDTH - 1);
                boolean endWall = (v == 0 || v == DEPTH - 1);
                if (sideWall || endWall) {
                    boolean corner = sideWall && endWall;
                    for (int h = 0; h <= 2; h++) {
                        put(at(u, v, h), corner ? log : planks);
                    }
                }
            }
        }

        // 3) windows (glass panes at eye level)
        int[][] windows = {
            {2, 0}, {6, 0},                 // front wall, either side of the door
            {2, 5}, {4, 5}, {6, 5},         // back wall
            {0, 2}, {0, 3}, {8, 2}, {8, 3}  // side walls
        };
        for (int[] w : windows) {
            BlockPos pos = at(w[0], w[1], 1);
            put(pos, Block.updateFromNeighbourShapes(Blocks.GLASS_PANE.defaultBlockState(), level, pos));
        }

        // 4) door (front wall, centre)
        BlockState door = Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING, fwd);
        put(at(4, 0, 0), door.setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER), FLAG_QUIET);
        put(at(4, 0, 1), door.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER), FLAG_QUIET);

        // 5) two beds, heads against the back wall
        BlockState bed = Blocks.RED_BED.defaultBlockState().setValue(BedBlock.FACING, fwd);
        for (int u = 1; u <= 2; u++) {
            put(at(u, 3, 0), bed.setValue(BedBlock.PART, BedPart.FOOT), FLAG_QUIET);
            put(at(u, 4, 0), bed.setValue(BedBlock.PART, BedPart.HEAD), FLAG_QUIET);
        }

        // 6) two chests by the front wall, facing into the room
        BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, fwd);
        put(at(1, 1, 0), chest);
        put(at(2, 1, 0), chest);

        // 7) crafting table + two furnaces along the back wall, facing into the room
        put(at(7, 4, 0), Blocks.CRAFTING_TABLE.defaultBlockState());
        BlockState furnace = Blocks.FURNACE.defaultBlockState()
                .setValue(AbstractFurnaceBlock.FACING, fwd.getOpposite());
        put(at(6, 4, 0), furnace);
        put(at(5, 4, 0), furnace);

        // 8) two hanging lanterns so mobs don't spawn inside
        BlockState lantern = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
        put(at(2, 2, 2), lantern);
        put(at(6, 2, 2), lantern);
    }
}
