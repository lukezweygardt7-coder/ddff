package com.ddff.ddffmod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Half a heart = 1.0 health.
 *  - At 1.0 health or less: all damage is cancelled (invincible) until health rises above 1.0.
 *  - Above 1.0 health: a hit that would kill you is shrunk so you land on exactly 1.0.
 * Void / /kill (damage that bypasses invulnerability) is NOT blocked.
 */
public class HalfHeartHandler {
    private static final float HALF_HEART = 1.0F;

    // LOWEST so we see the final damage after armor, enchantments and absorption.
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }

        float health = player.getHealth();

        if (health <= HALF_HEART) {
            event.setCanceled(true);
            return;
        }

        float maxSurvivable = health - HALF_HEART;
        if (event.getAmount() > maxSurvivable) {
            event.setAmount(maxSurvivable);
        }
    }
}
