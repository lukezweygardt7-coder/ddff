# ddff - one Forge 1.20.1 mod

Includes: Invincible But at 1/2 a heart, 8x dungeons/mineshafts, and /house.
Push to GitHub, run "Build mod" in the Actions tab, download the `ddff-mod` artifact.
